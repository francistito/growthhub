<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Apexa - Business Consulting HTML Template</title>
    <script src="<?php echo e(url('assets/js/vendor/color-modes.js')); ?>"></script>
    <meta name="description" content="GROWTH HUB - CONSULTANT AGENCY" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png" />
    <!-- Place favicon.ico in the root directory -->
    <!-- CSS here -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome-all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/odometer.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/swiper-bundle.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/default.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />
</head>
<body>
<!--Preloader-->
<div id="preloader">
    <div id="loader" class="loader">
        <div class="loader-container">
            <div class="loader-icon"><img src="<?php echo e(asset('assets/img/logo/preloader.png')); ?>" alt="Preloader" /></div>
        </div>
    </div>
</div>
<!--Preloader-end -->
<!-- Scroll-top -->
<button class="scroll__top scroll-to-target" data-target="html">
    <i class="fas fa-angle-up"></i>
</button>
<!-- Scroll-top-end-->
<!-- header-area -->

<?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header-area-end -->
<!-- main-area -->
<main class="fix">
    <!-- slider-area -->
<?php echo $__env->yieldContent('content'); ?>
    <!-- blog-post-area-end -->
</main>
<!-- main-area-end -->
<!-- footer-area -->
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- footer-area-end -->
<!-- JS here -->
<script src="<?php echo e(asset('assets/js/vendor/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.odometer.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.appear.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/gsap.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/ScrollTrigger.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/SplitText.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/gsap-animation.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.parallaxScroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/swiper-bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/ajax-form.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/wow.min.j')); ?>"></script>
<script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH /var/www/html/growthhub/resources/views/layouts/main.blade.php ENDPATH**/ ?>