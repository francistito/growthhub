<?php $__env->startSection('content'); ?>



    <?php echo $__env->make('components.home_components.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- slider-area-end -->
    <!-- features-area -->
    <?php echo $__env->make('components.home_components.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- features-area-end -->
    <!-- about-area -->
    <?php echo $__env->make('components.home_components.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- about-area-end -->
    <!-- services-area -->
    <?php echo $__env->make('components.home_components.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- services-area-end -->
    <!-- choose-area -->
    <?php echo $__env->make('components.home_components.choose', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- choose-area-two -->
    <!-- counter-area -->
    <?php echo $__env->make('components.home_components.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- counter-area-end -->
    <!-- request-area -->

    <!-- request-area-end -->
    <!-- project-area -->

    <!-- project-area-end -->
    <!-- marquee-area -->

    <!-- marquee-area-end -->
    <!-- team-area -->
    <?php echo $__env->make('components.home_components.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- team-area-end -->
    <!-- testimonial-area -->
    <?php echo $__env->make('components.home_components.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- testimonial-area-end -->
    <!-- brand-area -->
    <?php echo $__env->make('components.home_components.brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- brand-area-end -->
    <!-- blog-post-area -->
    <?php echo $__env->make('components.home_components.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/growthhub/resources/views/welcome.blade.php ENDPATH**/ ?>