<section class="features__area">
    <div class="container-fluid p-0">
        <div class="features__item-wrap">
            <div class="row g-0">
                <div class="col-lg-3 col-md-6">
                    <div class="features__item">
                        <div class="features__icon">
                            <i class="flaticon-financial-profit"></i>
                        </div>
                        <div class="features__content">
                            <h4 class="title"><a href="services-details.html">Finance Planning</a></h4>
                            <p>
                                Apexa helps youcona doing <br />
                                tempor incididunt.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="features__item">
                        <div class="features__icon">
                            <i class="flaticon-light-bulb"></i>
                        </div>
                        <div class="features__content">
                            <h4 class="title"><a href="services-details.html">Strategic Idea</a></h4>
                            <p>
                                Apexa helps youcona doing <br />
                                tempor incididunt.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="features__item">
                        <div class="features__icon">
                            <i class="flaticon-target"></i>
                        </div>
                        <div class="features__content">
                            <h4 class="title"><a href="services-details.html">Business Goal</a></h4>
                            <p>
                                Apexa helps youcona doing <br />
                                tempor incididunt.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="features__item">
                        <div class="features__icon">
                            <i class="flaticon-profit"></i>
                        </div>
                        <div class="features__content">
                            <h4 class="title"><a href="services-details.html">Marketing Growth</a></h4>
                            <p>
                                Apexa helps youcona doing <br />
                                tempor incididunt.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
