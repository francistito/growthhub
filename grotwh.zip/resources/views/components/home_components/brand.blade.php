<div class="brand__area-two">
    <div class="container">
        <div class="swiper-container brand-active">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="brand-item">
                        <img src="assets/img/brand/brand_img01.png" alt="Apexa" />
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="brand-item">
                        <img src="assets/img/brand/brand_img02.png" alt="Apexa" />
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="brand-item">
                        <img src="assets/img/brand/brand_img03.png" alt="Apexa" />
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="brand-item">
                        <img src="assets/img/brand/brand_img04.png" alt="Apexa" />
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="brand-item">
                        <img src="assets/img/brand/brand_img05.png" alt="Apexa" />
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="brand-item">
                        <img src="assets/img/brand/brand_img06.png" alt="Apexa" />
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="brand-item">
                        <img src="assets/img/brand/brand_img03.png" alt="Apexa" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
