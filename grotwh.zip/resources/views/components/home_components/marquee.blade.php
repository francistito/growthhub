<div class="marquee__area">
    <div class="marquee__wrap">
        <div class="marquee__box">
            <a data-hover="Marketing" href="services-details.html">Marketing</a>
            <a data-hover="Finance Advisor" href="services-details.html">Finance Advisor</a>
            <a data-hover="Investment" href="services-details.html">Investment</a>
            <a data-hover="Target" href="services-details.html">Target</a>
        </div>
        <div class="marquee__box">
            <a data-hover="Marketing" href="services-details.html">Marketing</a>
            <a data-hover="Finance Advisor" href="services-details.html">Finance Advisor</a>
            <a data-hover="Investment" href="services-details.html">Investment</a>
            <a data-hover="Target" href="services-details.html">Target</a>
        </div>
    </div>
</div>
